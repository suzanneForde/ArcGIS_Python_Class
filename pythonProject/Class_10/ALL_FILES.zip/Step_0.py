
#####
# Step 0 - Practice tasks before we start.
#####

# Task a: Run the buffer tool on Step_0_Data.zip/RI_Forest_Health_Works_Project_Points_All_Invasives.shp, with a
# distance of 1 mile:


# Task b: Dissolve your resulting buffer:


# Task c: On the original point file (RI_Forest_Health_Works_Project_Points_All_Invasives.shp), use a
# search cursor to print the "Owner" field within the attributes.

